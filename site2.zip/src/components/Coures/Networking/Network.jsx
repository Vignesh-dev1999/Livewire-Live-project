

export const Cybersecurity = () => {
    return (
        <div className="">
            <div className="bg-[url('https://web.archive.org/web/20240416125644im_/https://livewirecoimbatore.com/wp-content/uploads/2020/06/inner3.jpg')] h-[70vh]">
                <div>
                    <h1>Cyber securityBridge the Cybersecurity</h1>
                </div>
            </div>
        </div>
    )
}